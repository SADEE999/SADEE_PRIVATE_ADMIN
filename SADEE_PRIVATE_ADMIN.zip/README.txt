SADEE SOLUTIONS PRIVATE ADMIN
Standalone admin panel. Upload this folder as a separate site.
Uses Supabase Auth + RLS. Run supabase.sql in the Supabase SQL Editor before login.
Change STORE_URL in config.js to your public store URL if needed.
